<?php

$host = "localhost";
$user = "root";
$password = "";
$db   = "tugas_wma";

$conn = mysqli_connect($host, $user, $password, $db) or die("Gagal menghubungi server!");;

?>