package com.example.retrofit_volley.retrofit.model;

public class LoginRequest {
    
    private String no_telp;
    private String password;

    public String getno_telp() {
        return no_telp;
    }

    public void setno_telp(String no_telp) {
        this.no_telp = no_telp;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}
