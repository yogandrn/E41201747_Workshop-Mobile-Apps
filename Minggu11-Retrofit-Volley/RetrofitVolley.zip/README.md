# E41201367-Workshop-Mobile-App
API - CRUD with Retrofit - Login with Volley

NIM : E41201367

Nama : Fauzan Abdillah

1. CRUD with Retrofit:

![CRUD Retrofit](https://user-images.githubusercontent.com/74108522/142805684-cacaaf22-d256-405c-ad64-3538b9063ab5.gif)

2. Login with Volley:

![Login Volley](https://user-images.githubusercontent.com/74108522/142805716-2d3cb9b5-d920-4327-a10b-0d131c978669.gif)
